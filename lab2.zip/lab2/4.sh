#!/usr/bin/env bash
# 我们课上已经实践过了ssh命令，这里我们熟悉一下scp命令
# 实验：scp 批量下载 → 本地按后缀归类 → 打包上传到远端“组名”目录
# 实验目的
# 会用 scp：把服务器的/data/shenzm/workshop路径下的所有文件拉到本地。
# 会用 mkdir/mv/find/tar：按照后缀把文件分门别类，再整体打包。
# 会用 ssh + scp：把打好的包传回远端自己组名的目录（若目录不存在就创建）。
# 实验要求（一步步）
# 远端（目标服务器）上已有一堆文件，后缀包含 .a、.b、.c（可能数量不一样）。
# 把它们都下载到你本机一个工作目录（比如 work/），注意 scp 通配符写法：要让远端来匹配，防止本地提前展开。
# 在本地 work/ 里新建 a/ b/ c/ 三个文件夹，把 .a → a/，.b → b/，.c → c/。
# 把 a/ b/ c/ 三个文件夹一起打包成 abc_<你的组名>.tar.gz。
# 在远端提交目录下创建你们组名的文件夹（比如 /data/submit/<你的组名>/），把 tar 包上传到那里。
# 输出每一步的提示信息；如果某类后缀一个都没有，也要友好提示，但流程继续进行。

# 题目：scp 下载 .a/.b/.c → 本地按后缀归类 → 打包上传到远端组名目录
# 目的：
# - 从远端把/data/shenzm/workshop路径下的三类后缀文件拉回本地；
# - 在本地分三类存放；
# - 打一个总包；
# - 再把包传回远端你们组名目录。
# 只用 bash 基础命令 + scp + ssh + tar。

#!/usr/bin/env bash
# 题目：scp 下载 .a/.b/.c → 本地按后缀归类 → 打包上传到远端组名目录



# TODO: 使用mkdir命令创建本地目录

# TODO: 使用cd命令进入本地目录


# TODO: 远端 → 本地下载（让远端匹配通配符，故把远端路径整体加引号）
# scp（远端 → 本地） 
# 注意：1. scp下载过程中可以使用正则表达式表示文件，请查询如何基于后缀写对应文件正则
# 注意：2. scp命令基于ssh，也需要考虑访问端口
# 参考 scp <user>@<host>:<remote_path> <local_dest_dir>/


# 本地创建分类目录
mkdir a
mkdir b
mkdir c

# TODO: 本地按后缀归类，将所有的.a/.b/.c文件分别移动到对应目录
# 参考 mv work/downloads/*.a a/



# TODO: 打包（注意用 -C 避免把绝对路径打进包内）
# 参考 tar -czf <output.tar.gz> -C <work_dir> <item1> <item2> ...


# TODO: scp（本地 → 远端）
# scp <local_path_of_file> "<user>@<host>:<remote_dest_dir>/"

PS D:\大学\人工智能工程实践> mkdir work


    目录: D:\大学\人工智能工程实践


Mode                 LastWriteTime         Length Name
----                 -------------         ------ ----
d-----          2025-9-4     20:24                work


PS D:\大学\人工智能工程实践> cd work
PS D:\大学\人工智能工程实践\work> scp -P 20205 gpu-user7@10.214.242.192:/data/shenzm/workshop/*.a ./
gpu-user7@10.214.242.192's password: 
1231.a                                                                                                                                            100%    0     0.0KB/s   00:00    
1756733246062952767_13978.a                                                                                                                       100%   28     8.7KB/s   00:00     
1756733246065700703_18894.a                                                                                                                       100%   28     7.9KB/s   00:00    
1756733246068507628_11475.a                                                                                                                       100%   28     8.5KB/s   00:00     
1.a                                                                                                                                               100%    0     0.0KB/s   00:00     
dasj.a                                                                                                                                            100%    0     0.0KB/s   00:00     
PS D:\大学\人工智能工程实践\work> scp -P 20205 gpu-user7@10.214.242.192:/data/shenzm/workshop/*.b ./
gpu-user7@10.214.242.192's password: 
1756733246071171468_29107.b                                                                                                                       100%   28     9.2KB/s   00:00    
1756733246073072752_17529.b                                                                                                                       100%   28    12.3KB/s   00:00     
1756733246075589207_8235.b                                                                                                                        100%   28    13.7KB/s   00:00     
1756733246077763039_6123.b                                                                                                                        100%   28    12.9KB/s   00:00    
1756733246080252839_20595.b                                                                                                                       100%   28     8.1KB/s   00:00     
1756733246082205147_22581.b                                                                                                                       100%   28     8.5KB/s   00:00     
1756733246084329537_3726.b                                                                                                                        100%   28    13.8KB/s   00:00     
1756733246086808607_6542.b                                                                                                                        100%   28     6.8KB/s   00:00     
1.b                                                                                                                                               100%    0     0.0KB/s   00:00    
akdsndnakn.b                                                                                                                                      100%    0     0.0KB/s   00:00     
asjddasjjh.b                                                                                                                                      100%    0     0.0KB/s   00:00     
PS D:\大学\人工智能工程实践\work> scp -P 20205 gpu-user7@10.214.242.192:/data/shenzm/workshop/*.c ./
gpu-user7@10.214.242.192's password: 
1756733246088883090_19658.c                                                                                                                       100%   28     9.1KB/s   00:00    
1756733246091328530_28895.c                                                                                                                       100%   28     3.1KB/s   00:00     
1756733246093692502_23825.c                                                                                                                       100%   28     8.0KB/s   00:00     
1756733246096350913_18208.c                                                                                                                       100%   28     9.1KB/s   00:00     
1756733246099001202_6024.c                                                                                                                        100%   28    13.7KB/s   00:00     
1756733246101237814_31889.c                                                                                                                       100%   28    13.7KB/s   00:00    
1756733246103910959_9777.c                                                                                                                        100%   28    13.7KB/s   00:00     
1sdad.c                                                                                                                                           100%    0     0.0KB/s   00:00     
assca.c                                                                                                                                           100%    0     0.0KB/s   00:00     
dasksadnj.c                                                                                                                                       100%    0     0.0KB/s   00:00    
PS D:\大学\人工智能工程实践\work> mkdir a


    目录: D:\大学\人工智能工程实践\work


Mode                 LastWriteTime         Length Name
----                 -------------         ------ ----
d-----          2025-9-4     20:28                a


PS D:\大学\人工智能工程实践\work> mkdir b


    目录: D:\大学\人工智能工程实践\work


Mode                 LastWriteTime         Length Name
----                 -------------         ------ ----
d-----          2025-9-4     20:28                b


PS D:\大学\人工智能工程实践\work> mkdir c


    目录: D:\大学\人工智能工程实践\work


Mode                 LastWriteTime         Length Name
----                 -------------         ------ ----
d-----          2025-9-4     20:28                c



PS D:\大学\人工智能工程实践\work> mv *.a a/
PS D:\大学\人工智能工程实践\work> mv *.b b/
PS D:\大学\人工智能工程实践\work> mv *.c c/                                                                                                                                         PS D:\大学\人工智能工程实践\work> tar -czf zzx_3240102118.tar.gz a b c                                                                                                              tar : 无法将“tar”项识别为 cmdlet、函数、脚本文件或可运行程序的名称。请检查名称的拼写，如果包括路径，请确保路径正确，然后再试一次。                                                  所在位置 行:1 字符: 1                                                                                                                                                               + tar -czf zzx_3240102118.tar.gz a b c                                                                                                                                            

PS D:\大学\人工智能工程实践\work> Compress-Archive -Path a, b, c -DestinationPath zzx_3240102118.zip
PS D:\大学\人工智能工程实践\work> Rename-Item zzx_3240102118.zip zzx_3240102118.tar.gz
PS D:\大学\人工智能工程实践\work> scp -P 20205 zzx_3240102118.tar.gz gpu-user7@10.214.242.192:/home/shenzm/workspace/home/gpu-user7
gpu-user7@10.214.242.192's password: 
zzx_3240102118.tar.gz                                                                                                                             100% 3780   925.0KB/s   00:00    






